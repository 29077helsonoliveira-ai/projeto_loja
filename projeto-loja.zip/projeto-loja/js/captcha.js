// js/captcha.js - Sistema de CAPTCHA matemático

function generateCaptcha() {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    
    let answer;
    let questionText;
    
    switch(operation) {
        case '+':
            answer = num1 + num2;
            questionText = `${num1} + ${num2}`;
            break;
        case '-':
            answer = num1 - num2;
            questionText = `${num1} - ${num2}`;
            break;
        case '*':
            answer = num1 * num2;
            questionText = `${num1} × ${num2}`;
            break;
    }
    
    return { question: questionText, answer: answer };
}

// Gerar CAPTCHA quando a página carrega
document.addEventListener('DOMContentLoaded', function() {
    const captchaQuestion = document.getElementById('captchaQuestion');
    const captchaAnswer = document.getElementById('captchaAnswer');
    
    if (captchaQuestion && captchaAnswer) {
        const captcha = generateCaptcha();
        captchaQuestion.textContent = captcha.question;
        captchaAnswer.value = captcha.answer;
    }
});

// Adicionar validação visual ao CAPTCHA
const captchaInput = document.getElementById('captcha');
if (captchaInput) {
    captchaInput.addEventListener('input', function() {
        const answer = parseInt(document.getElementById('captchaAnswer').value);
        const userAnswer = parseInt(this.value);
        
        if (userAnswer === answer) {
            this.style.borderColor = '#10b981';
            this.style.boxShadow = '0 0 10px rgba(16, 185, 129, 0.5)';
        } else {
            this.style.borderColor = 'rgba(255, 255, 255, 0.1)';
            this.style.boxShadow = 'none';
        }
    });
}