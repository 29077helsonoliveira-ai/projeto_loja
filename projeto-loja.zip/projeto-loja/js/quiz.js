// js/quiz.js - Sistema de quiz interativo de escolha múltipla

/**
 * Base de dados de perguntas do quiz
 */
const quizDatabase = [
    {
        id: 1,
        question: "Qual foi o primeiro computador pessoal comercialmente bem-sucedido?",
        options: [
            "IBM PC",
            "Apple II",
            "Commodore 64",
            "Altair 8800"
        ],
        correct: 1,
        explanation: "O Apple II, lançado em 1977, foi um dos primeiros computadores pessoais comercialmente bem-sucedidos, ajudando a popularizar os computadores domésticos.",
        difficulty: "medium"
    },
    {
        id: 2,
        question: "O que significa 'RAM' em informática?",
        options: [
            "Random Access Memory",
            "Rapid Application Module",
            "Read And Modify",
            "Runtime Application Manager"
        ],
        correct: 0,
        explanation: "RAM significa Random Access Memory (Memória de Acesso Aleatório), um tipo de memória volátil usada para armazenar dados temporariamente.",
        difficulty: "easy"
    },
    {
        id: 3,
        question: "Qual empresa criou o sistema operativo Android?",
        options: [
            "Apple",
            "Microsoft",
            "Google",
            "Samsung"
        ],
        correct: 2,
        explanation: "O Android foi desenvolvido pela Android Inc., que foi adquirida pela Google em 2005. Hoje é o sistema operativo móvel mais usado no mundo.",
        difficulty: "easy"
    },
    {
        id: 4,
        question: "Quantos bits tem um byte?",
        options: [
            "4 bits",
            "8 bits",
            "16 bits",
            "32 bits"
        ],
        correct: 1,
        explanation: "Um byte é composto por 8 bits. Esta é uma unidade fundamental de medida em informática.",
        difficulty: "easy"
    },
    {
        id: 5,
        question: "Qual é a resolução 4K em pixels?",
        options: [
            "1920 x 1080",
            "2560 x 1440",
            "3840 x 2160",
            "7680 x 4320"
        ],
        correct: 2,
        explanation: "4K (Ultra HD) tem resolução de 3840 x 2160 pixels, oferecendo quatro vezes mais pixels que Full HD (1080p).",
        difficulty: "medium"
    },
    {
        id: 6,
        question: "Qual linguagem de programação é conhecida como a 'linguagem da web'?",
        options: [
            "Python",
            "JavaScript",
            "Java",
            "C++"
        ],
        correct: 1,
        explanation: "JavaScript é considerada a linguagem da web, executando nativamente nos navegadores e permitindo criar páginas interativas.",
        difficulty: "easy"
    },
    {
        id: 7,
        question: "O que é um 'SSD'?",
        options: [
            "Super Speed Drive",
            "Solid State Drive",
            "Standard Storage Device",
            "Secure System Disk"
        ],
        correct: 1,
        explanation: "SSD significa Solid State Drive, um dispositivo de armazenamento sem partes móveis que usa memória flash, sendo muito mais rápido que HDD tradicional.",
        difficulty: "medium"
    },
    {
        id: 8,
        question: "Qual protocolo é usado para transferir páginas web?",
        options: [
            "FTP",
            "SMTP",
            "HTTP",
            "TCP"
        ],
        correct: 2,
        explanation: "HTTP (HyperText Transfer Protocol) é o protocolo usado para transferir páginas web entre servidores e clientes (navegadores).",
        difficulty: "medium"
    },
    {
        id: 9,
        question: "Qual a velocidade de transmissão do USB 3.0?",
        options: [
            "480 Mbps",
            "5 Gbps",
            "10 Gbps",
            "20 Gbps"
        ],
        correct: 1,
        explanation: "USB 3.0 (também conhecido como SuperSpeed USB) oferece velocidades de até 5 Gbps, cerca de 10 vezes mais rápido que USB 2.0.",
        difficulty: "hard"
    },
    {
        id: 10,
        question: "Quem é considerado o 'pai da computação'?",
        options: [
            "Steve Jobs",
            "Bill Gates",
            "Alan Turing",
            "Tim Berners-Lee"
        ],
        correct: 2,
        explanation: "Alan Turing é considerado o pai da computação moderna, tendo desenvolvido conceitos fundamentais como a Máquina de Turing e contribuído para decifração de códigos na Segunda Guerra Mundial.",
        difficulty: "medium"
    }
];

/**
 * Classe principal do Quiz
 */
class Quiz {
    constructor(questions) {
        this.questions = questions;
        this.currentQuestion = 0;
        this.score = 0;
        this.answers = [];
        this.startTime = null;
        this.endTime = null;
        this.timePerQuestion = [];
    }
    
    /**
     * Iniciar o quiz
     */
    start() {
        this.currentQuestion = 0;
        this.score = 0;
        this.answers = [];
        this.startTime = new Date();
        this.timePerQuestion = [];
        console.log('🎮 Quiz iniciado!');
        console.log(`📝 Total de perguntas: ${this.questions.length}`);
    }
    
    /**
     * Obter pergunta atual
     */
    getCurrentQuestion() {
        return this.questions[this.currentQuestion];
    }
    
    /**
     * Verificar resposta
     */
    checkAnswer(selectedOption) {
        const question = this.getCurrentQuestion();
        const isCorrect = selectedOption === question.correct;
        
        // Registar resposta
        this.answers[this.currentQuestion] = {
            questionId: question.id,
            selected: selectedOption,
            correct: question.correct,
            isCorrect: isCorrect,
            timestamp: new Date()
        };
        
        // Atualizar pontuação
        if (isCorrect) {
            this.score++;
        }
        
        console.log(`${isCorrect ? '✅' : '❌'} Pergunta ${this.currentQuestion + 1}: ${isCorrect ? 'Correta' : 'Errada'}`);
        
        return {
            isCorrect: isCorrect,
            correctAnswer: question.correct,
            explanation: question.explanation
        };
    }
    
    /**
     * Avançar para próxima pergunta
     */
    nextQuestion() {
        if (this.currentQuestion < this.questions.length - 1) {
            this.currentQuestion++;
            return true;
        }
        return false;
    }
    
    /**
     * Voltar para pergunta anterior
     */
    previousQuestion() {
        if (this.currentQuestion > 0) {
            this.currentQuestion--;
            return true;
        }
        return false;
    }
    
    /**
     * Ir para pergunta específica
     */
    goToQuestion(index) {
        if (index >= 0 && index < this.questions.length) {
            this.currentQuestion = index;
            return true;
        }
        return false;
    }
    
    /**
     * Verificar se quiz está completo
     */
    isComplete() {
        return this.answers.length === this.questions.length;
    }
    
    /**
     * Obter progresso
     */
    getProgress() {
        return {
            current: this.currentQuestion + 1,
            total: this.questions.length,
            percentage: Math.round(((this.currentQuestion + 1) / this.questions.length) * 100)
        };
    }
    
    /**
     * Obter resultados finais
     */
    getResults() {
        this.endTime = new Date();
        const timeTaken = Math.round((this.endTime - this.startTime) / 1000); // em segundos
        const percentage = Math.round((this.score / this.questions.length) * 100);
        
        let grade = '';
        let message = '';
        
        if (percentage === 100) {
            grade = 'A+';
            message = '🏆 Perfeito! És um verdadeiro expert em tecnologia!';
        } else if (percentage >= 90) {
            grade = 'A';
            message = '🌟 Excelente! Dominas muito bem o tema!';
        } else if (percentage >= 80) {
            grade = 'B+';
            message = '👏 Muito bom! Tens bons conhecimentos!';
        } else if (percentage >= 70) {
            grade = 'B';
            message = '👍 Bom trabalho! Estás no caminho certo!';
        } else if (percentage >= 60) {
            grade = 'C+';
            message = '📚 Razoável. Continua a estudar!';
        } else if (percentage >= 50) {
            grade = 'C';
            message = '📖 Precisas de rever alguns conceitos.';
        } else {
            grade = 'D';
            message = '💪 Não desistas! Há sempre mais para aprender!';
        }
        
        const results = {
            score: this.score,
            total: this.questions.length,
            percentage: percentage,
            grade: grade,
            message: message,
            timeTaken: timeTaken,
            answers: this.answers,
            correctAnswers: this.answers.filter(a => a.isCorrect).length,
            wrongAnswers: this.answers.filter(a => !a.isCorrect).length
        };
        
        console.log('📊 Resultados do Quiz:');
        console.log(`   Pontuação: ${results.score}/${results.total} (${results.percentage}%)`);
        console.log(`   Nota: ${results.grade}`);
        console.log(`   Tempo: ${results.timeTaken}s`);
        
        return results;
    }
    
    /**
     * Reiniciar quiz
     */
    restart() {
        this.start();
        console.log('🔄 Quiz reiniciado!');
    }
    
    /**
     * Obter estatísticas detalhadas
     */
    getDetailedStats() {
        const results = this.getResults();
        
        // Análise por dificuldade
        const byDifficulty = {
            easy: { correct: 0, total: 0 },
            medium: { correct: 0, total: 0 },
            hard: { correct: 0, total: 0 }
        };
        
        this.answers.forEach((answer, index) => {
            const question = this.questions[index];
            const difficulty = question.difficulty || 'medium';
            
            byDifficulty[difficulty].total++;
            if (answer.isCorrect) {
                byDifficulty[difficulty].correct++;
            }
        });
        
        return {
            ...results,
            byDifficulty: byDifficulty,
            averageTimePerQuestion: results.timeTaken / this.questions.length
        };
    }
}

/**
 * Interface do Quiz - Funções de UI
 */
class QuizUI {
    constructor(quiz, containerId) {
        this.quiz = quiz;
        this.container = document.getElementById(containerId);
        this.questionStartTime = null;
    }
    
    /**
     * Renderizar pergunta atual
     */
    renderQuestion() {
        const question = this.quiz.getCurrentQuestion();
        const progress = this.quiz.getProgress();
        const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
        
        this.questionStartTime = new Date();
        
        const html = `
            <div class="question-card active">
                <div class="question-header">
                    <span class="question-number">Pergunta ${progress.current} de ${progress.total}</span>
                    <span style="color: var(--text-gray);">⏱️ Sem limite de tempo</span>
                </div>
                
                <div class="question-text">
                    ${question.question}
                </div>
                
                <div class="options">
                    ${question.options.map((opt, idx) => `
                        <div class="option" data-option="${idx}">
                            <span class="option-letter">${letters[idx]}</span>
                            <span>${opt}</span>
                        </div>
                    `).join('')}
                </div>
                
                <div id="explanation" style="margin-top: 1.5rem; padding: 1rem; background: rgba(139, 92, 246, 0.1); border-radius: 10px; display: none;">
                    <strong>💡 Explicação:</strong> <span id="explanationText"></span>
                </div>
                
                <div class="quiz-buttons">
                    <button class="btn" id="prevBtn" ${progress.current === 1 ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : ''}>
                        ← Anterior
                    </button>
                    <button class="btn btn-primary" id="nextBtn" disabled style="opacity: 0.5;">
                        ${progress.current === progress.total ? 'Ver Resultados →' : 'Próxima →'}
                    </button>
                </div>
            </div>
        `;
        
        this.container.innerHTML = html;
        this.attachEventListeners();
        this.updateProgressBar();
    }
    
    /**
     * Anexar event listeners
     */
    attachEventListeners() {
        // Opções de resposta
        document.querySelectorAll('.option').forEach(option => {
            option.addEventListener('click', (e) => {
                const selectedOption = parseInt(e.currentTarget.dataset.option);
                this.handleAnswer(selectedOption);
            });
        });
        
        // Botões de navegação
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', () => this.handlePrevious());
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => this.handleNext());
        }
    }
    
    /**
     * Tratar resposta selecionada
     */
    handleAnswer(selectedOption) {
        const result = this.quiz.checkAnswer(selectedOption);
        const options = document.querySelectorAll('.option');
        const nextBtn = document.getElementById('nextBtn');
        const explanation = document.getElementById('explanation');
        const explanationText = document.getElementById('explanationText');
        
        // Remover seleção anterior
        options.forEach(opt => {
            opt.classList.remove('selected', 'correct', 'wrong');
            opt.style.pointerEvents = 'none';
        });
        
        // Marcar opção selecionada
        options[selectedOption].classList.add('selected');
        
        // Mostrar se está correta ou errada
        if (result.isCorrect) {
            options[selectedOption].classList.add('correct');
        } else {
            options[selectedOption].classList.add('wrong');
            options[result.correctAnswer].classList.add('correct');
        }
        
        // Mostrar explicação
        if (explanationText && explanation) {
            explanationText.textContent = result.explanation;
            explanation.style.display = 'block';
        }
        
        // Habilitar botão próximo
        if (nextBtn) {
            nextBtn.disabled = false;
            nextBtn.style.opacity = '1';
        }
    }
    
    /**
     * Navegar para pergunta anterior
     */
    handlePrevious() {
        if (this.quiz.previousQuestion()) {
            this.renderQuestion();
        }
    }
    
    /**
     * Navegar para próxima pergunta ou mostrar resultados
     */
    handleNext() {
        if (this.quiz.nextQuestion()) {
            this.renderQuestion();
        } else {
            this.showResults();
        }
    }
    
    /**
     * Atualizar barra de progresso
     */
    updateProgressBar() {
        const progress = this.quiz.getProgress();
        const progressBar = document.getElementById('progressBar');
        
        if (progressBar) {
            progressBar.style.width = progress.percentage + '%';
        }
    }
    
    /**
     * Mostrar resultados finais
     */
    showResults() {
        const results = this.quiz.getResults();
        const stats = this.quiz.getDetailedStats();
        
        this.container.style.display = 'none';
        const resultsCard = document.getElementById('resultsCard');
        
        if (resultsCard) {
            resultsCard.classList.add('active');
            
            document.getElementById('finalScore').textContent = results.percentage + '%';
            document.getElementById('scoreMessage').textContent = results.message;
            document.getElementById('correctAnswers').textContent = results.correctAnswers;
            document.getElementById('totalQuestions').textContent = results.total;
        }
        
        // Log detalhado no console
        console.log('📊 Estatísticas Detalhadas:');
        console.log('   Por dificuldade:', stats.byDifficulty);
        console.log('   Tempo médio por pergunta:', Math.round(stats.averageTimePerQuestion) + 's');
    }
}

/**
 * Função global para reiniciar o quiz
 */
function restartQuiz() {
    const quizContent = document.getElementById('quizContent');
    const resultsCard = document.getElementById('resultsCard');
    
    if (quizContent && resultsCard) {
        quizContent.style.display = 'block';
        resultsCard.classList.remove('active');
    }
    
    if (window.quizInstance) {
        window.quizInstance.restart();
        window.quizUIInstance.renderQuestion();
    }
}

/**
 * Inicialização automática quando o DOM estiver pronto
 */
document.addEventListener('DOMContentLoaded', function() {
    const quizContent = document.getElementById('quizContent');
    
    if (quizContent) {
        // Criar instâncias do quiz
        window.quizInstance = new Quiz(quizDatabase);
        window.quizUIInstance = new QuizUI(window.quizInstance, 'quizContent');
        
        // Iniciar o quiz
        window.quizInstance.start();
        window.quizUIInstance.renderQuestion();
        
        console.log('🎮 Sistema de Quiz carregado!');
        console.log('📚 Base de dados:', quizDatabase);
    }
});

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Quiz, QuizUI, quizDatabase };
}