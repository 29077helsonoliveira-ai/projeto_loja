// js/main.js - JavaScript principal

// Menu Mobile
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
}

// Animação da Lâmpada (se existir na página)
if (typeof gsap !== 'undefined') {
    const { registerPlugin, set, to, timeline } = gsap;
    if (typeof MorphSVGPlugin !== 'undefined') {
        registerPlugin(MorphSVGPlugin);
    }

    const ON = document.querySelector("#on");
    const OFF = document.querySelector("#off");
    const FORM = document.querySelector(".form-container");
    const LAMP = document.querySelector(".lamp");

    if (LAMP) {
        const AUDIO = {
            CLICK: new Audio("https://assets.codepen.io/605876/click.mp3")
        };

        let startX, startY;
        const PROXY = document.createElement("div");
        const CORDS = gsap.utils.toArray(".cords path");
        const CORD_DURATION = 0.1;
        const HIT = document.querySelector(".lamp__hit");
        const DUMMY_CORD = document.querySelector(".cord--dummy");
        const ENDX = DUMMY_CORD.getAttribute("x2");
        const ENDY = DUMMY_CORD.getAttribute("y2");

        const RESET = () => {
            set(PROXY, { x: ENDX, y: ENDY });
        };
        RESET();

        const STATE = { ON: false };

        gsap.set([".cords", HIT], { x: -10 });
        gsap.set(".lamp__eye", {
            rotate: 180,
            transformOrigin: "50% 50%",
            yPercent: 50
        });

        const CORD_TL = timeline({
            paused: true,
            onStart: () => {
                STATE.ON = !STATE.ON;
                set(document.documentElement, { "--on": STATE.ON ? 1 : 0 });
                
                const hue = gsap.utils.random(0, 359);
                set(document.documentElement, { "--shade-hue": hue });
                
                const glowColor = `hsl(${hue}, 40%, 45%)`;
                const glowColorDark = `hsl(${hue}, 40%, 35%)`;
                set(document.documentElement, {
                    "--glow-color": glowColor,
                    "--glow-color-dark": glowColorDark
                });

                set(".lamp__eye", { rotate: STATE.ON ? 0 : 180 });
                set([DUMMY_CORD, HIT], { display: "none" });
                set(CORDS[0], { display: "block" });

                try {
                    AUDIO.CLICK.play();
                } catch(e) {}

                if (STATE.ON) {
                    if (ON) ON.setAttribute("checked", true);
                    if (OFF) OFF.removeAttribute("checked");
                    if (FORM) FORM.classList.add("active");
                } else {
                    if (ON) ON.removeAttribute("checked");
                    if (OFF) OFF.setAttribute("checked", true);
                    if (FORM) FORM.classList.remove("active");
                }
            },
            onComplete: () => {
                set([DUMMY_CORD, HIT], { display: "block" });
                set(CORDS[0], { display: "none" });
                RESET();
            }
        });

        if (typeof MorphSVGPlugin !== 'undefined') {
            for (let i = 1; i < CORDS.length; i++) {
                CORD_TL.add(
                    to(CORDS[0], {
                        morphSVG: CORDS[i],
                        duration: CORD_DURATION,
                        repeat: 1,
                        yoyo: true
                    })
                );
            }
        }

        if (typeof Draggable !== 'undefined') {
            Draggable.create(PROXY, {
                trigger: HIT,
                type: "x,y",
                onPress: (e) => {
                    startX = e.x;
                    startY = e.y;
                },
                onDrag: function() {
                    set(DUMMY_CORD, {
                        attr: {
                            x2: this.x,
                            y2: Math.max(400, this.y)
                        }
                    });
                },
                onRelease: function(e) {
                    const DISTX = Math.abs(e.x - startX);
                    const DISTY = Math.abs(e.y - startY);
                    const TRAVELLED = Math.sqrt(DISTX * DISTX + DISTY * DISTY);
                    
                    to(DUMMY_CORD, {
                        attr: { x2: ENDX, y2: ENDY },
                        duration: CORD_DURATION,
                        onComplete: () => {
                            if (TRAVELLED > 50) {
                                CORD_TL.restart();
                            } else {
                                RESET();
                            }
                        }
                    });
                }
            });
        }

        gsap.set(".lamp", { display: "block" });
    }
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// Animação de entrada para cards
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '0';
            entry.target.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                entry.target.style.transition = 'all 0.6s ease';
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }, 100);
            
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.card, .product-card').forEach(card => {
    observer.observe(card);
});