<?php
// index.php - Página principal
require_once 'php/config.php';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechStore - Sua Loja de Tecnologia</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/carousel.css">
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="index.php" class="logo">🛍️ TechStore</a>
            <button class="menu-toggle" id="menuToggle">☰</button>
            <ul class="nav-links" id="navLinks">
                <li><a href="index.php">Início</a></li>
                <li><a href="products.php">Produtos</a></li>
                <li><a href="quiz.php">Quiz</a></li>
                <li><a href="contact.php">Contacto</a></li>
                <?php if(isLoggedIn()): ?>
                    <li><a href="#">👤 <?= $_SESSION['username'] ?></a></li>
                    <li><a href="logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Registo</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container">
        <!-- Hero Section -->
        <section class="hero">
            <h1 style="font-size: 3rem; text-align: center; margin: 2rem 0;">
                Bem-vindo à <span style="background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">TechStore</span>
            </h1>
            <p style="text-align: center; font-size: 1.2rem; color: var(--text-gray); margin-bottom: 3rem;">
                A sua loja online de tecnologia com os melhores produtos
            </p>
        </section>

        <!-- Carrossel de Imagens -->
        <section class="carousel-section">
            <h2 style="font-size: 2rem; margin-bottom: 2rem; text-align: center;">🔥 Destaques</h2>
            <div class="carousel-container">
                <div class="carousel">
                    <div class="carousel-slide active">
                        <div class="slide-content">
                            <span style="font-size: 8rem;">💻</span>
                            <h3>Laptops Gaming</h3>
                            <p>Performance máxima para os teus jogos</p>
                        </div>
                    </div>
                    <div class="carousel-slide">
                        <div class="slide-content">
                            <span style="font-size: 8rem;">📱</span>
                            <h3>Smartphones</h3>
                            <p>Tecnologia de ponta sempre contigo</p>
                        </div>
                    </div>
                    <div class="carousel-slide">
                        <div class="slide-content">
                            <span style="font-size: 8rem;">🎧</span>
                            <h3>Áudio Premium</h3>
                            <p>Qualidade de som incomparável</p>
                        </div>
                    </div>
                    <div class="carousel-slide">
                        <div class="slide-content">
                            <span style="font-size: 8rem;">⌚</span>
                            <h3>Wearables</h3>
                            <p>Tecnologia vestível inteligente</p>
                        </div>
                    </div>
                </div>
                <button class="carousel-btn prev" onclick="moveCarousel(-1)">❮</button>
                <button class="carousel-btn next" onclick="moveCarousel(1)">❯</button>
                <div class="carousel-dots"></div>
            </div>
        </section>

        <!-- Categorias -->
        <section style="margin: 4rem 0;">
            <h2 style="font-size: 2rem; margin-bottom: 2rem; text-align: center;">📦 Categorias</h2>
            <div class="products-grid">
                <div class="card" style="text-align: center; cursor: pointer;" onclick="location.href='products.php?category=Eletrónica'">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">🖥️</div>
                    <h3>Eletrónica</h3>
                    <p style="color: var(--text-gray);">Computadores, tablets e mais</p>
                </div>
                <div class="card" style="text-align: center; cursor: pointer;" onclick="location.href='products.php?category=Áudio'">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">🎵</div>
                    <h3>Áudio</h3>
                    <p style="color: var(--text-gray);">Auscultadores e sistemas de som</p>
                </div>
                <div class="card" style="text-align: center; cursor: pointer;" onclick="location.href='products.php?category=Wearables'">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">⌚</div>
                    <h3>Wearables</h3>
                    <p style="color: var(--text-gray);">Smartwatches e fitness trackers</p>
                </div>
                <div class="card" style="text-align: center; cursor: pointer;" onclick="location.href='products.php?category=Fotografia'">
                    <div style="font-size: 4rem; margin-bottom: 1rem;">📷</div>
                    <h3>Fotografia</h3>
                    <p style="color: var(--text-gray);">Câmaras e acessórios</p>
                </div>
            </div>
        </section>

        <!-- Features -->
        <section style="margin: 4rem 0;">
            <h2 style="font-size: 2rem; margin-bottom: 2rem; text-align: center;">✨ Porquê Escolher-nos?</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
                <div class="card" style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🚚</div>
                    <h3>Entrega Rápida</h3>
                    <p style="color: var(--text-gray);">Receba em 24-48h</p>
                </div>
                <div class="card" style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">💯</div>
                    <h3>Garantia</h3>
                    <p style="color: var(--text-gray);">2 anos em todos os produtos</p>
                </div>
                <div class="card" style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">💳</div>
                    <h3>Pagamento Seguro</h3>
                    <p style="color: var(--text-gray);">Proteção total nas compras</p>
                </div>
                <div class="card" style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🎁</div>
                    <h3>Ofertas</h3>
                    <p style="color: var(--text-gray);">Promoções exclusivas</p>
                </div>
            </div>
        </section>
    </div>

    <footer style="background: var(--bg-card); padding: 2rem; text-align: center; margin-top: 4rem;">
        <p style="color: var(--text-gray);">© 2024 TechStore - Todos os direitos reservados</p>
        <p style="color: var(--text-gray); margin-top: 0.5rem;">
            <a href="contact.php" style="color: var(--primary); text-decoration: none;">Contacte-nos</a> | 
            <a href="quiz.php" style="color: var(--primary); text-decoration: none;">Quiz Tecnológico</a>
        </p>
    </footer>

    <script src="js/carousel.js"></script>
    <script src="js/main.js"></script>
</body>
</html>