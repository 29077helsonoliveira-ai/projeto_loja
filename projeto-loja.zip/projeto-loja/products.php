<?php
// products.php - Listagem de produtos (VISÍVEL SEM LOGIN)
require_once 'php/config.php';

$category = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Processar compra
$purchase_message = '';
if (isset($_POST['buy_product'])) {
    if (!isLoggedIn()) {
        $purchase_message = 'error|Por favor, faça login para comprar produtos!';
    } else {
        $product_id = (int)$_POST['product_id'];
        $product_name = sanitize($_POST['product_name']);
        $product_price = sanitize($_POST['product_price']);
        
        // Aqui você pode adicionar lógica de compra/carrinho
        // Por enquanto, vamos simular uma compra bem-sucedida
        $purchase_message = "success|✅ '{$product_name}' adicionado ao carrinho! Total: €{$product_price}";
    }
}

try {
    $conn = getConnection();
    
    $query = "SELECT * FROM products WHERE 1=1";
    $params = [];
    
    if ($category) {
        $query .= " AND category = ?";
        $params[] = $category;
    }
    
    if ($search) {
        $query .= " AND (name LIKE ? OR description LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $query .= " ORDER BY created_at DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $products = [];
    $error = "Erro ao carregar produtos: " . $e->getMessage();
}

// Obter categorias únicas
try {
    $stmt = $conn->query("SELECT DISTINCT category FROM products ORDER BY category");
    $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch(PDOException $e) {
    $categories = [];
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - TechStore</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="index.php" class="logo">🛍️ TechStore</a>
            <button class="menu-toggle" id="menuToggle">☰</button>
            <ul class="nav-links" id="navLinks">
                <li><a href="index.php">Início</a></li>
                <li><a href="products.php">Produtos</a></li>
                <li><a href="quiz.php">Quiz</a></li>
                <li><a href="contact.php">Contacto</a></li>
                <?php if(isLoggedIn()): ?>
                    <li><a href="#">👤 <?= $_SESSION['username'] ?></a></li>
                    <li><a href="logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Registo</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1 style="font-size: 2.5rem; margin: 2rem 0; text-align: center;">
            <span style="background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                📦 Nossos Produtos
            </span>
        </h1>

        <!-- Mensagem de compra -->
        <?php if($purchase_message): 
            list($type, $message) = explode('|', $purchase_message);
        ?>
            <div class="alert alert-<?= $type ?>" id="purchaseAlert">
                <?= $message ?>
                <?php if($type === 'error'): ?>
                    <br><a href="login.php" style="color: var(--primary); text-decoration: underline;">Ir para Login</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Filtros -->
        <div class="card" style="margin-bottom: 2rem;">
            <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
                <div class="form-group" style="flex: 1; min-width: 200px; margin-bottom: 0;">
                    <label for="search">🔍 Pesquisar</label>
                    <input type="text" id="search" name="search" placeholder="Nome do produto..." value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="form-group" style="flex: 1; min-width: 200px; margin-bottom: 0;">
                    <label for="category">📂 Categoria</label>
                    <select id="category" name="category">
                        <option value="">Todas as categorias</option>
                        <?php foreach($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary" style="margin-bottom: 0;">Filtrar</button>
                <a href="products.php" class="btn" style="background: var(--bg-card); color: var(--text-light); margin-bottom: 0;">Limpar</a>
            </form>
        </div>

        <!-- Estatísticas -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
            <div class="card" style="text-align: center; padding: 1.5rem;">
                <div style="font-size: 2rem; color: var(--primary);">📊</div>
                <div style="font-size: 2rem; font-weight: bold; margin: 0.5rem 0;"><?= count($products) ?></div>
                <div style="color: var(--text-gray);">Produtos encontrados</div>
            </div>
            <div class="card" style="text-align: center; padding: 1.5rem;">
                <div style="font-size: 2rem; color: var(--secondary);">📂</div>
                <div style="font-size: 2rem; font-weight: bold; margin: 0.5rem 0;"><?= count($categories) ?></div>
                <div style="color: var(--text-gray);">Categorias disponíveis</div>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>

        <?php if (empty($products)): ?>
            <div class="card" style="text-align: center; padding: 3rem;">
                <div style="font-size: 5rem; margin-bottom: 1rem;">🔍</div>
                <h3>Nenhum produto encontrado</h3>
                <p style="color: var(--text-gray); margin-top: 1rem;">
                    Tente ajustar os filtros ou <a href="products.php" style="color: var(--primary);">ver todos os produtos</a>
                </p>
            </div>
        <?php else: ?>
            <!-- Lista de Produtos -->
            <div class="products-grid" id="productsGrid">
                <?php 
                $icons = ['💻', '📱', '🎧', '⌚', '📷', '🖱️', '⌨️', '🖥️'];
                foreach($products as $index => $product): 
                    $icon = $icons[$index % count($icons)];
                ?>
                    <div class="product-card" data-product='<?= json_encode($product) ?>'>
                        <div class="product-image" style="background: linear-gradient(135deg, <?= $index % 2 === 0 ? 'var(--primary), var(--secondary)' : 'var(--secondary), var(--accent)' ?>);">
                            <span style="font-size: 4rem;"><?= $icon ?></span>
                        </div>
                        <div class="product-info">
                            <div style="display: inline-block; background: rgba(139, 92, 246, 0.2); color: var(--primary); padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; margin-bottom: 0.5rem;">
                                <?= htmlspecialchars($product['category']) ?>
                            </div>
                            <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                            <p class="product-description"><?= htmlspecialchars($product['description']) ?></p>
                            <div class="product-price">€<?= number_format($product['price'], 2, ',', '.') ?></div>
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 1rem; gap: 0.5rem;">
                                <span style="color: <?= $product['stock'] > 0 ? 'var(--success)' : 'var(--error)' ?>; font-size: 0.9rem;">
                                    <?= $product['stock'] > 0 ? "✓ Em stock ({$product['stock']})" : '✗ Esgotado' ?>
                                </span>
                                <?php if($product['stock'] > 0): ?>
                                    <form method="POST" style="margin: 0;">
                                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                        <input type="hidden" name="product_name" value="<?= htmlspecialchars($product['name']) ?>">
                                        <input type="hidden" name="product_price" value="<?= $product['price'] ?>">
                                        <button type="submit" name="buy_product" class="btn btn-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem;">
                                            🛒 Comprar
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <footer style="background: var(--bg-card); padding: 2rem; text-align: center; margin-top: 4rem;">
        <p style="color: var(--text-gray);">© 2024 TechStore - Todos os direitos reservados</p>
    </footer>

    <script src="js/main.js"></script>
    <script>
        // Demonstração de manipulação de arrays/objetos JavaScript
        const productsData = <?= json_encode($products) ?>;
        
        console.log('📦 Total de produtos:', productsData.length);
        console.log('💰 Produtos carregados:', productsData);
        
        // Calcular estatísticas
        if (productsData.length > 0) {
            const totalValue = productsData.reduce((sum, p) => sum + parseFloat(p.price), 0);
            const avgPrice = totalValue / productsData.length;
            const maxPrice = Math.max(...productsData.map(p => parseFloat(p.price)));
            const minPrice = Math.min(...productsData.map(p => parseFloat(p.price)));
            
            console.log('📊 Estatísticas:');
            console.log('  - Preço médio: €' + avgPrice.toFixed(2));
            console.log('  - Preço máximo: €' + maxPrice.toFixed(2));
            console.log('  - Preço mínimo: €' + minPrice.toFixed(2));
            
            // Agrupar por categoria
            const byCategory = productsData.reduce((acc, product) => {
                const cat = product.category;
                if (!acc[cat]) acc[cat] = [];
                acc[cat].push(product);
                return acc;
            }, {});
            
            console.log('📂 Produtos por categoria:', byCategory);
        }
        
        // Auto-fechar alerta de compra após 5 segundos
        const alert = document.getElementById('purchaseAlert');
        if (alert) {
            setTimeout(() => {
                alert.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => alert.remove(), 300);
            }, 5000);
        }
        
        // Adicionar efeito de hover nos cards
        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                const data = JSON.parse(this.dataset.product);
                console.log('👁️ A visualizar:', data.name);
            });
        });
    </script>
    
    <style>
        @keyframes slideOut {
            from {
                opacity: 1;
                transform: translateY(0);
            }
            to {
                opacity: 0;
                transform: translateY(-20px);
            }
        }
    </style>
</body>
</html>