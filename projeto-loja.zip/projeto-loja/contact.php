<?php
// contact.php - Formulário de contacto
require_once 'php/config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);
    $captcha_input = $_POST['captcha'];
    $captcha_answer = $_POST['captcha_answer'];
    
    if (empty($name) || empty($email) || empty($message)) {
        $error = 'Por favor, preencha todos os campos obrigatórios!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email inválido!';
    } elseif ($captcha_input != $captcha_answer) {
        $error = 'CAPTCHA incorreto!';
    } else {
        try {
            $conn = getConnection();
            $stmt = $conn->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $subject, $message]);
            
            $success = 'Mensagem enviada com sucesso! Entraremos em contacto em breve.';
            
            // Limpar campos
            $name = $email = $subject = $message = '';
        } catch(PDOException $e) {
            $error = 'Erro ao enviar mensagem: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto - TechStore</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="index.php" class="logo">🛍️ TechStore</a>
            <button class="menu-toggle" id="menuToggle">☰</button>
            <ul class="nav-links" id="navLinks">
                <li><a href="index.php">Início</a></li>
                <li><a href="products.php">Produtos</a></li>
                <li><a href="quiz.php">Quiz</a></li>
                <li><a href="contact.php">Contacto</a></li>
                <?php if(isLoggedIn()): ?>
                    <li><a href="#">👤 <?= $_SESSION['username'] ?></a></li>
                    <li><a href="logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Registo</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1 style="font-size: 2.5rem; margin: 2rem 0; text-align: center;">
            <span style="background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                📧 Entre em Contacto
            </span>
        </h1>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-top: 3rem;">
            <!-- Informações de Contacto -->
            <div>
                <div class="card" style="margin-bottom: 2rem;">
                    <h2 style="margin-bottom: 1.5rem;">📍 Informações</h2>
                    
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; align-items: start;">
                        <div style="font-size: 2rem;">📧</div>
                        <div>
                            <h3 style="margin-bottom: 0.5rem;">Email</h3>
                            <p style="color: var(--text-gray);">suporte@techstore.pt</p>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; align-items: start;">
                        <div style="font-size: 2rem;">📞</div>
                        <div>
                            <h3 style="margin-bottom: 0.5rem;">Telefone</h3>
                            <p style="color: var(--text-gray);">+351 123 456 789</p>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; align-items: start;">
                        <div style="font-size: 2rem;">🏢</div>
                        <div>
                            <h3 style="margin-bottom: 0.5rem;">Morada</h3>
                            <p style="color: var(--text-gray);">Rua da Tecnologia, 123<br>4400-000 Maia, Porto</p>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; align-items: start;">
                        <div style="font-size: 2rem;">⏰</div>
                        <div>
                            <h3 style="margin-bottom: 0.5rem;">Horário</h3>
                            <p style="color: var(--text-gray);">
                                Segunda a Sexta: 9h - 19h<br>
                                Sábado: 10h - 14h<br>
                                Domingo: Fechado
                            </p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <h2 style="margin-bottom: 1.5rem;">💬 FAQ Rápido</h2>
                    
                    <div style="margin-bottom: 1rem;">
                        <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Como fazer uma encomenda?</h3>
                        <p style="color: var(--text-gray); font-size: 0.9rem;">Adicione produtos ao carrinho e finalize a compra no checkout.</p>
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Quais os métodos de pagamento?</h3>
                        <p style="color: var(--text-gray); font-size: 0.9rem;">Aceitamos cartões de crédito, débito e MB Way.</p>
                    </div>
                    
                    <div>
                        <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Quanto tempo demora a entrega?</h3>
                        <p style="color: var(--text-gray); font-size: 0.9rem;">Entregas em 24-48h em Portugal Continental.</p>
                    </div>
                </div>
            </div>

            <!-- Formulário de Contacto -->
            <div>
                <div class="card">
                    <h2 style="margin-bottom: 1.5rem;">✉️ Envie uma Mensagem</h2>
                    
                    <?php if($success): ?>
                        <div class="alert alert-success"><?= $success ?></div>
                    <?php endif; ?>
                    
                    <?php if($error): ?>
                        <div class="alert alert-error"><?= $error ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" id="contactForm">
                        <div class="form-group">
                            <label for="name">Nome *</label>
                            <input type="text" id="name" name="name" placeholder="O seu nome" value="<?= htmlspecialchars($name ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" placeholder="seu@email.com" value="<?= htmlspecialchars($email ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="subject">Assunto</label>
                            <select id="subject" name="subject">
                                <option value="Informação Geral">Informação Geral</option>
                                <option value="Suporte Técnico">Suporte Técnico</option>
                                <option value="Encomendas">Encomendas</option>
                                <option value="Devoluções">Devoluções</option>
                                <option value="Parcerias">Parcerias</option>
                                <option value="Outro">Outro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Mensagem *</label>
                            <textarea id="message" name="message" placeholder="Escreva a sua mensagem aqui..." rows="6" required><?= htmlspecialchars($message ?? '') ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>CAPTCHA: Quanto é <span id="captchaQuestion"></span>? *</label>
                            <input type="number" id="captcha" name="captcha" placeholder="Resposta" required>
                            <input type="hidden" id="captchaAnswer" name="captcha_answer">
                        </div>
                        
                        <button type="submit" name="send_message" class="btn btn-primary btn-full">
                            📤 Enviar Mensagem
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Estatísticas -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-top: 3rem;">
            <div class="card" style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 0.5rem;">⚡</div>
                <h3 style="font-size: 2rem; margin: 0.5rem 0;">< 2h</h3>
                <p style="color: var(--text-gray);">Tempo de resposta</p>
            </div>
            <div class="card" style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 0.5rem;">😊</div>
                <h3 style="font-size: 2rem; margin: 0.5rem 0;">98%</h3>
                <p style="color: var(--text-gray);">Satisfação do cliente</p>
            </div>
            <div class="card" style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 0.5rem;">💬</div>
                <h3 style="font-size: 2rem; margin: 0.5rem 0;">1000+</h3>
                <p style="color: var(--text-gray);">Mensagens respondidas</p>
            </div>
            <div class="card" style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 0.5rem;">⭐</div>
                <h3 style="font-size: 2rem; margin: 0.5rem 0;">4.9/5</h3>
                <p style="color: var(--text-gray);">Avaliação do suporte</p>
            </div>
        </div>
    </div>

    <footer style="background: var(--bg-card); padding: 2rem; text-align: center; margin-top: 4rem;">
        <p style="color: var(--text-gray);">© 2024 TechStore - Todos os direitos reservados</p>
    </footer>

    <script src="js/captcha.js"></script>
    <script src="js/main.js"></script>
    <script>
        // Validação em tempo real
        const form = document.getElementById('contactForm');
        const email = document.getElementById('email');
        const message = document.getElementById('message');
        
        email.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(this.value) && this.value !== '') {
                this.style.borderColor = 'var(--error)';
            } else {
                this.style.borderColor = '';
            }
        });
        
        message.addEventListener('input', function() {
            const charCount = this.value.length;
            const maxChars = 500;
            
            if (charCount > maxChars) {
                this.value = this.value.substring(0, maxChars);
            }
        });
        
        // Contador de caracteres
        const messageInput = document.getElementById('message');
        const counter = document.createElement('div');
        counter.style.cssText = 'text-align: right; color: var(--text-gray); font-size: 0.85rem; margin-top: 0.5rem;';
        messageInput.parentElement.appendChild(counter);
        
        messageInput.addEventListener('input', function() {
            counter.textContent = `${this.value.length} / 500 caracteres`;
        });
        counter.textContent = '0 / 500 caracteres';
    </script>
</body>
</html>