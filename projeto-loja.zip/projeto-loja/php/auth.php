<?php
// php/auth.php - Sistema de autenticação

require_once 'config.php';

/**
 * Classe de Autenticação
 */
class Auth {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    /**
     * Registar novo utilizador
     */
    public function register($username, $email, $password) {
        try {
            // Validar dados
            if (empty($username) || empty($email) || empty($password)) {
                return [
                    'success' => false,
                    'message' => 'Todos os campos são obrigatórios!'
                ];
            }
            
            // Validar email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return [
                    'success' => false,
                    'message' => 'Email inválido!'
                ];
            }
            
            // Validar comprimento da password
            if (strlen($password) < 6) {
                return [
                    'success' => false,
                    'message' => 'A password deve ter pelo menos 6 caracteres!'
                ];
            }
            
            // Verificar se username ou email já existem
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->rowCount() > 0) {
                return [
                    'success' => false,
                    'message' => 'Username ou email já existem!'
                ];
            }
            
            // Hash da password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Inserir utilizador
            $stmt = $this->conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $hashedPassword]);
            
            return [
                'success' => true,
                'message' => 'Conta criada com sucesso!',
                'user_id' => $this->conn->lastInsertId()
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao criar conta: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Fazer login
     */
    public function login($username, $password) {
        try {
            // Validar dados
            if (empty($username) || empty($password)) {
                return [
                    'success' => false,
                    'message' => 'Preencha todos os campos!'
                ];
            }
            
            // Buscar utilizador
            $stmt = $this->conn->prepare("SELECT id, username, password, email FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            
            if ($stmt->rowCount() === 0) {
                return [
                    'success' => false,
                    'message' => 'Utilizador não encontrado!'
                ];
            }
            
            $user = $stmt->fetch();
            
            // Verificar password
            if (!password_verify($password, $user['password'])) {
                return [
                    'success' => false,
                    'message' => 'Password incorreta!'
                ];
            }
            
            // Criar sessão
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['login_time'] = time();
            
            return [
                'success' => true,
                'message' => 'Login efetuado com sucesso!',
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email']
                ]
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro no login: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Fazer logout
     */
    public function logout() {
        session_destroy();
        return [
            'success' => true,
            'message' => 'Logout efetuado com sucesso!'
        ];
    }
    
    /**
     * Verificar se utilizador está autenticado
     */
    public function isAuthenticated() {
        return isset($_SESSION['user_id']);
    }
    
    /**
     * Obter dados do utilizador atual
     */
    public function getCurrentUser() {
        if (!$this->isAuthenticated()) {
            return null;
        }
        
        try {
            $stmt = $this->conn->prepare("SELECT id, username, email, created_at FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            
            if ($stmt->rowCount() > 0) {
                return $stmt->fetch();
            }
            
            return null;
            
        } catch(PDOException $e) {
            return null;
        }
    }
    
    /**
     * Atualizar perfil do utilizador
     */
    public function updateProfile($userId, $data) {
        try {
            $fields = [];
            $values = [];
            
            if (isset($data['username']) && !empty($data['username'])) {
                $fields[] = "username = ?";
                $values[] = $data['username'];
            }
            
            if (isset($data['email']) && !empty($data['email'])) {
                if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                    return [
                        'success' => false,
                        'message' => 'Email inválido!'
                    ];
                }
                $fields[] = "email = ?";
                $values[] = $data['email'];
            }
            
            if (empty($fields)) {
                return [
                    'success' => false,
                    'message' => 'Nenhum campo para atualizar!'
                ];
            }
            
            $values[] = $userId;
            $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($values);
            
            return [
                'success' => true,
                'message' => 'Perfil atualizado com sucesso!'
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao atualizar perfil: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Mudar password
     */
    public function changePassword($userId, $oldPassword, $newPassword) {
        try {
            // Validar nova password
            if (strlen($newPassword) < 6) {
                return [
                    'success' => false,
                    'message' => 'A nova password deve ter pelo menos 6 caracteres!'
                ];
            }
            
            // Verificar password atual
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!password_verify($oldPassword, $user['password'])) {
                return [
                    'success' => false,
                    'message' => 'Password atual incorreta!'
                ];
            }
            
            // Atualizar password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            
            return [
                'success' => true,
                'message' => 'Password alterada com sucesso!'
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao alterar password: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Verificar se username está disponível
     */
    public function isUsernameAvailable($username) {
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            return $stmt->rowCount() === 0;
        } catch(PDOException $e) {
            return false;
        }
    }
    
    /**
     * Verificar se email está disponível
     */
    public function isEmailAvailable($email) {
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            return $stmt->rowCount() === 0;
        } catch(PDOException $e) {
            return false;
        }
    }
    
    /**
     * Obter total de utilizadores
     */
    public function getTotalUsers() {
        try {
            $stmt = $this->conn->query("SELECT COUNT(*) as total FROM users");
            $result = $stmt->fetch();
            return $result['total'];
        } catch(PDOException $e) {
            return 0;
        }
    }
    
    /**
     * Obter utilizadores recentes
     */
    public function getRecentUsers($limit = 10) {
        try {
            $stmt = $this->conn->prepare("SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT ?");
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
}

// Exemplo de uso:
/*
$auth = new Auth();

// Registar
$result = $auth->register('username', 'email@example.com', 'password123');

// Login
$result = $auth->login('username', 'password123');

// Verificar autenticação
if ($auth->isAuthenticated()) {
    $user = $auth->getCurrentUser();
}

// Logout
$auth->logout();
*/
?>