<?php
// php/products_data.php - Gestão de dados de produtos

require_once 'config.php';

/**
 * Classe de Produtos
 */
class Products {
    private $conn;
    
    public function __construct() {
        $this->conn = getConnection();
    }
    
    /**
     * Obter todos os produtos
     */
    public function getAllProducts($orderBy = 'created_at', $order = 'DESC') {
        try {
            $allowedColumns = ['name', 'price', 'created_at', 'stock', 'category'];
            $orderBy = in_array($orderBy, $allowedColumns) ? $orderBy : 'created_at';
            $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';
            
            $sql = "SELECT * FROM products ORDER BY $orderBy $order";
            $stmt = $this->conn->query($sql);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Obter produto por ID
     */
    public function getProductById($id) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            return null;
        }
    }
    
    /**
     * Obter produtos por categoria
     */
    public function getProductsByCategory($category) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM products WHERE category = ? ORDER BY created_at DESC");
            $stmt->execute([$category]);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Pesquisar produtos
     */
    public function searchProducts($query) {
        try {
            $searchTerm = "%$query%";
            $stmt = $this->conn->prepare("
                SELECT * FROM products 
                WHERE name LIKE ? OR description LIKE ? OR category LIKE ?
                ORDER BY created_at DESC
            ");
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Filtrar produtos
     */
    public function filterProducts($filters = []) {
        try {
            $where = [];
            $params = [];
            
            // Filtro por categoria
            if (isset($filters['category']) && !empty($filters['category'])) {
                $where[] = "category = ?";
                $params[] = $filters['category'];
            }
            
            // Filtro por preço mínimo
            if (isset($filters['min_price']) && is_numeric($filters['min_price'])) {
                $where[] = "price >= ?";
                $params[] = $filters['min_price'];
            }
            
            // Filtro por preço máximo
            if (isset($filters['max_price']) && is_numeric($filters['max_price'])) {
                $where[] = "price <= ?";
                $params[] = $filters['max_price'];
            }
            
            // Filtro por disponibilidade
            if (isset($filters['in_stock']) && $filters['in_stock'] === true) {
                $where[] = "stock > 0";
            }
            
            // Filtro por pesquisa
            if (isset($filters['search']) && !empty($filters['search'])) {
                $searchTerm = "%" . $filters['search'] . "%";
                $where[] = "(name LIKE ? OR description LIKE ?)";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            $sql = "SELECT * FROM products";
            if (!empty($where)) {
                $sql .= " WHERE " . implode(" AND ", $where);
            }
            $sql .= " ORDER BY created_at DESC";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
            
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Obter categorias únicas
     */
    public function getCategories() {
        try {
            $stmt = $this->conn->query("SELECT DISTINCT category FROM products ORDER BY category");
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Adicionar novo produto
     */
    public function addProduct($data) {
        try {
            // Validar dados obrigatórios
            if (empty($data['name']) || empty($data['price'])) {
                return [
                    'success' => false,
                    'message' => 'Nome e preço são obrigatórios!'
                ];
            }
            
            // Validar preço
            if (!is_numeric($data['price']) || $data['price'] < 0) {
                return [
                    'success' => false,
                    'message' => 'Preço inválido!'
                ];
            }
            
            $stmt = $this->conn->prepare("
                INSERT INTO products (name, description, price, category, stock, image) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['name'],
                $data['description'] ?? null,
                $data['price'],
                $data['category'] ?? 'Geral',
                $data['stock'] ?? 0,
                $data['image'] ?? null
            ]);
            
            return [
                'success' => true,
                'message' => 'Produto adicionado com sucesso!',
                'product_id' => $this->conn->lastInsertId()
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao adicionar produto: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Atualizar produto
     */
    public function updateProduct($id, $data) {
        try {
            $fields = [];
            $values = [];
            
            if (isset($data['name']) && !empty($data['name'])) {
                $fields[] = "name = ?";
                $values[] = $data['name'];
            }
            
            if (isset($data['description'])) {
                $fields[] = "description = ?";
                $values[] = $data['description'];
            }
            
            if (isset($data['price']) && is_numeric($data['price'])) {
                $fields[] = "price = ?";
                $values[] = $data['price'];
            }
            
            if (isset($data['category'])) {
                $fields[] = "category = ?";
                $values[] = $data['category'];
            }
            
            if (isset($data['stock']) && is_numeric($data['stock'])) {
                $fields[] = "stock = ?";
                $values[] = $data['stock'];
            }
            
            if (isset($data['image'])) {
                $fields[] = "image = ?";
                $values[] = $data['image'];
            }
            
            if (empty($fields)) {
                return [
                    'success' => false,
                    'message' => 'Nenhum campo para atualizar!'
                ];
            }
            
            $values[] = $id;
            $sql = "UPDATE products SET " . implode(", ", $fields) . " WHERE id = ?";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($values);
            
            return [
                'success' => true,
                'message' => 'Produto atualizado com sucesso!'
            ];
            
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao atualizar produto: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Eliminar produto
     */
    public function deleteProduct($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            
            return [
                'success' => true,
                'message' => 'Produto eliminado com sucesso!'
            ];
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao eliminar produto: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Atualizar stock
     */
    public function updateStock($id, $quantity) {
        try {
            $stmt = $this->conn->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
            $stmt->execute([$quantity, $id]);
            
            return [
                'success' => true,
                'message' => 'Stock atualizado com sucesso!'
            ];
        } catch(PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao atualizar stock: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Verificar disponibilidade
     */
    public function isAvailable($id, $quantity = 1) {
        try {
            $stmt = $this->conn->prepare("SELECT stock FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch();
            
            if ($product) {
                return $product['stock'] >= $quantity;
            }
            
            return false;
        } catch(PDOException $e) {
            return false;
        }
    }
    
    /**
     * Obter estatísticas
     */
    public function getStatistics() {
        try {
            $stats = [];
            
            // Total de produtos
            $stmt = $this->conn->query("SELECT COUNT(*) as total FROM products");
            $stats['total_products'] = $stmt->fetch()['total'];
            
            // Produtos em stock
            $stmt = $this->conn->query("SELECT COUNT(*) as total FROM products WHERE stock > 0");
            $stats['in_stock'] = $stmt->fetch()['total'];
            
            // Produtos esgotados
            $stmt = $this->conn->query("SELECT COUNT(*) as total FROM products WHERE stock = 0");
            $stats['out_of_stock'] = $stmt->fetch()['total'];
            
            // Preço médio
            $stmt = $this->conn->query("SELECT AVG(price) as avg_price FROM products");
            $stats['average_price'] = round($stmt->fetch()['avg_price'], 2);
            
            // Produto mais caro
            $stmt = $this->conn->query("SELECT MAX(price) as max_price FROM products");
            $stats['max_price'] = $stmt->fetch()['max_price'];
            
            // Produto mais barato
            $stmt = $this->conn->query("SELECT MIN(price) as min_price FROM products WHERE price > 0");
            $stats['min_price'] = $stmt->fetch()['min_price'];
            
            // Total de categorias
            $stmt = $this->conn->query("SELECT COUNT(DISTINCT category) as total FROM products");
            $stats['total_categories'] = $stmt->fetch()['total'];
            
            return $stats;
            
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Obter produtos mais recentes
     */
    public function getRecentProducts($limit = 10) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM products ORDER BY created_at DESC LIMIT ?");
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Obter produtos por faixa de preço
     */
    public function getProductsByPriceRange($minPrice, $maxPrice) {
        try {
            $stmt = $this->conn->prepare("
                SELECT * FROM products 
                WHERE price BETWEEN ? AND ? 
                ORDER BY price ASC
            ");
            $stmt->execute([$minPrice, $maxPrice]);
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
    
    /**
     * Obter produtos em destaque (com mais stock)
     */
    public function getFeaturedProducts($limit = 6) {
        try {
            $stmt = $this->conn->prepare("
                SELECT * FROM products 
                WHERE stock > 0 
                ORDER BY stock DESC 
                LIMIT ?
            ");
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }
}

// Exemplo de uso:
/*
$products = new Products();

// Obter todos os produtos
$allProducts = $products->getAllProducts();

// Pesquisar produtos
$results = $products->searchProducts('laptop');

// Filtrar produtos
$filtered = $products->filterProducts([
    'category' => 'Eletrónica',
    'min_price' => 100,
    'max_price' => 1000,
    'in_stock' => true
]);

// Obter estatísticas
$stats = $products->getStatistics();

// Adicionar produto
$result = $products->addProduct([
    'name' => 'Novo Produto',
    'description' => 'Descrição do produto',
    'price' => 99.99,
    'category' => 'Eletrónica',
    'stock' => 10
]);
*/
?>