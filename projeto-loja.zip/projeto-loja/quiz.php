<?php
// quiz.php - Quiz de escolha múltipla
require_once 'php/config.php';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Tecnológico - TechStore</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .quiz-container {
            max-width: 800px;
            margin: 2rem auto;
        }
        
        .question-card {
            background: var(--bg-card);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            display: none;
            animation: slideIn 0.5s ease;
        }
        
        .question-card.active {
            display: block;
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }
        
        .question-number {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
        }
        
        .question-text {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .options {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .option {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .option:hover {
            border-color: var(--primary);
            background: rgba(139, 92, 246, 0.1);
            transform: translateX(5px);
        }
        
        .option.selected {
            border-color: var(--primary);
            background: rgba(139, 92, 246, 0.2);
        }
        
        .option.correct {
            border-color: var(--success);
            background: rgba(16, 185, 129, 0.2);
        }
        
        .option.wrong {
            border-color: var(--error);
            background: rgba(239, 68, 68, 0.2);
        }
        
        .option-letter {
            background: var(--primary);
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .quiz-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 2rem;
        }
        
        .progress-bar {
            background: rgba(255, 255, 255, 0.1);
            height: 10px;
            border-radius: 5px;
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .progress-fill {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            height: 100%;
            transition: width 0.5s ease;
            border-radius: 5px;
        }
        
        .results-card {
            display: none;
            text-align: center;
            padding: 3rem;
        }
        
        .results-card.active {
            display: block;
        }
        
        .score-circle {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 2rem auto;
            font-size: 3rem;
            font-weight: bold;
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.5);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="index.php" class="logo">🛍️ TechStore</a>
            <button class="menu-toggle" id="menuToggle">☰</button>
            <ul class="nav-links" id="navLinks">
                <li><a href="index.php">Início</a></li>
                <li><a href="products.php">Produtos</a></li>
                <li><a href="quiz.php">Quiz</a></li>
                <li><a href="contact.php">Contacto</a></li>
                <?php if(isLoggedIn()): ?>
                    <li><a href="#">👤 <?= $_SESSION['username'] ?></a></li>
                    <li><a href="logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Registo</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="container quiz-container">
        <h1 style="font-size: 2.5rem; margin: 2rem 0; text-align: center;">
            <span style="background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                🧠 Quiz Tecnológico
            </span>
        </h1>
        
        <p style="text-align: center; color: var(--text-gray); margin-bottom: 3rem;">
            Teste os seus conhecimentos sobre tecnologia!
        </p>

        <div class="card">
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar" style="width: 0%"></div>
            </div>
            
            <div id="quizContent"></div>
            
            <div class="results-card" id="resultsCard">
                <h2 style="font-size: 2.5rem; margin-bottom: 1rem;">🎉 Quiz Concluído!</h2>
                <div class="score-circle">
                    <span id="finalScore">0%</span>
                </div>
                <h3 style="font-size: 1.5rem; margin: 2rem 0;" id="scoreMessage"></h3>
                <p style="color: var(--text-gray); margin-bottom: 2rem;">
                    Acertou <span id="correctAnswers" style="color: var(--success); font-weight: bold;">0</span> de 
                    <span id="totalQuestions" style="color: var(--primary); font-weight: bold;">0</span> perguntas
                </p>
                <button class="btn btn-primary" onclick="restartQuiz()">🔄 Tentar Novamente</button>
                <a href="products.php" class="btn" style="background: var(--bg-card); margin-left: 1rem;">🛍️ Ver Produtos</a>
            </div>
        </div>
    </div>

    <footer style="background: var(--bg-card); padding: 2rem; text-align: center; margin-top: 4rem;">
        <p style="color: var(--text-gray);">© 2024 TechStore - Todos os direitos reservados</p>
    </footer>

    <script src="js/main.js"></script>
    <script>
        // Array de perguntas do quiz
        const quizQuestions = [
            {
                question: "Qual foi o primeiro computador pessoal comercialmente bem-sucedido?",
                options: [
                    "IBM PC",
                    "Apple II",
                    "Commodore 64",
                    "Altair 8800"
                ],
                correct: 1,
                explanation: "O Apple II, lançado em 1977, foi um dos primeiros computadores pessoais comercialmente bem-sucedidos."
            },
            {
                question: "O que significa 'RAM' em informática?",
                options: [
                    "Random Access Memory",
                    "Rapid Application Module",
                    "Read And Modify",
                    "Runtime Application Manager"
                ],
                correct: 0,
                explanation: "RAM significa Random Access Memory (Memória de Acesso Aleatório)."
            },
            {
                question: "Qual empresa criou o sistema operativo Android?",
                options: [
                    "Apple",
                    "Microsoft",
                    "Google",
                    "Samsung"
                ],
                correct: 2,
                explanation: "O Android foi desenvolvido pela Android Inc., que foi comprada pela Google em 2005."
            },
            {
                question: "Quantos bits tem um byte?",
                options: [
                    "4 bits",
                    "8 bits",
                    "16 bits",
                    "32 bits"
                ],
                correct: 1,
                explanation: "Um byte é composto por 8 bits."
            },
            {
                question: "Qual é a resolução 4K em pixels?",
                options: [
                    "1920 x 1080",
                    "2560 x 1440",
                    "3840 x 2160",
                    "7680 x 4320"
                ],
                correct: 2,
                explanation: "4K (Ultra HD) tem resolução de 3840 x 2160 pixels."
            },
            {
                question: "Qual linguagem de programação é conhecida como a 'linguagem da web'?",
                options: [
                    "Python",
                    "JavaScript",
                    "Java",
                    "C++"
                ],
                correct: 1,
                explanation: "JavaScript é considerada a linguagem da web, executando no navegador."
            },
            {
                question: "O que é um 'SSD'?",
                options: [
                    "Super Speed Drive",
                    "Solid State Drive",
                    "Standard Storage Device",
                    "Secure System Disk"
                ],
                correct: 1,
                explanation: "SSD significa Solid State Drive, um dispositivo de armazenamento sem partes móveis."
            },
            {
                question: "Qual protocolo é usado para transferir páginas web?",
                options: [
                    "FTP",
                    "SMTP",
                    "HTTP",
                    "TCP"
                ],
                correct: 2,
                explanation: "HTTP (HyperText Transfer Protocol) é usado para transferir páginas web."
            }
        ];

        let currentQuestion = 0;
        let score = 0;
        let answers = [];

        function initQuiz() {
            currentQuestion = 0;
            score = 0;
            answers = [];
            showQuestion();
        }

        function showQuestion() {
            const quizContent = document.getElementById('quizContent');
            const question = quizQuestions[currentQuestion];
            const letters = ['A', 'B', 'C', 'D'];
            
            const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            
            quizContent.innerHTML = `
                <div class="question-card active">
                    <div class="question-header">
                        <span class="question-number">Pergunta ${currentQuestion + 1} de ${quizQuestions.length}</span>
                        <span style="color: var(--text-gray);">⏱️ Sem limite de tempo</span>
                    </div>
                    
                    <div class="question-text">
                        ${question.question}
                    </div>
                    
                    <div class="options">
                        ${question.options.map((opt, idx) => `
                            <div class="option" onclick="selectOption(${idx})">
                                <span class="option-letter">${letters[idx]}</span>
                                <span>${opt}</span>
                            </div>
                        `).join('')}
                    </div>
                    
                    <div id="explanation" style="margin-top: 1.5rem; padding: 1rem; background: rgba(139, 92, 246, 0.1); border-radius: 10px; display: none;">
                        <strong>💡 Explicação:</strong> <span id="explanationText"></span>
                    </div>
                    
                    <div class="quiz-buttons">
                        <button class="btn" onclick="previousQuestion()" ${currentQuestion === 0 ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : ''}>
                            ← Anterior
                        </button>
                        <button class="btn btn-primary" id="nextBtn" onclick="nextQuestion()" disabled style="opacity: 0.5;">
                            ${currentQuestion === quizQuestions.length - 1 ? 'Ver Resultados →' : 'Próxima →'}
                        </button>
                    </div>
                </div>
            `;
        }

        function selectOption(optionIndex) {
            const options = document.querySelectorAll('.option');
            const question = quizQuestions[currentQuestion];
            const nextBtn = document.getElementById('nextBtn');
            const explanation = document.getElementById('explanation');
            const explanationText = document.getElementById('explanationText');
            
            // Remover seleção anterior
            options.forEach(opt => {
                opt.classList.remove('selected', 'correct', 'wrong');
            });
            
            // Marcar opção selecionada
            options[optionIndex].classList.add('selected');
            
            // Verificar resposta
            if (optionIndex === question.correct) {
                options[optionIndex].classList.add('correct');
                if (answers[currentQuestion] === undefined) {
                    score++;
                }
            } else {
                options[optionIndex].classList.add('wrong');
                options[question.correct].classList.add('correct');
            }
            
            // Mostrar explicação
            explanationText.textContent = question.explanation;
            explanation.style.display = 'block';
            
            // Salvar resposta
            answers[currentQuestion] = optionIndex;
            
            // Habilitar botão próximo
            nextBtn.disabled = false;
            nextBtn.style.opacity = '1';
        }

        function nextQuestion() {
            if (answers[currentQuestion] === undefined) return;
            
            currentQuestion++;
            
            if (currentQuestion < quizQuestions.length) {
                showQuestion();
            } else {
                showResults();
            }
        }

        function previousQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                showQuestion();
            }
        }

        function showResults() {
            document.getElementById('quizContent').style.display = 'none';
            document.getElementById('resultsCard').classList.add('active');
            
            const percentage = Math.round((score / quizQuestions.length) * 100);
            document.getElementById('finalScore').textContent = percentage + '%';
            document.getElementById('correctAnswers').textContent = score;
            document.getElementById('totalQuestions').textContent = quizQuestions.length;
            
            let message = '';
            if (percentage === 100) {
                message = '🏆 Perfeito! És um verdadeiro expert em tecnologia!';
            } else if (percentage >= 75) {
                message = '🌟 Excelente! Conheces muito sobre tecnologia!';
            } else if (percentage >= 50) {
                message = '👍 Bom trabalho! Continua a aprender!';
            } else {
                message = '📚 Não desistas! Há sempre mais para aprender!';
            }
            
            document.getElementById('scoreMessage').textContent = message;
            
            console.log('📊 Resultados do Quiz:');
            console.log(`   Score: ${score}/${quizQuestions.length} (${percentage}%)`);
            console.log(`   Respostas:`, answers);
        }

        function restartQuiz() {
            document.getElementById('quizContent').style.display = 'block';
            document.getElementById('resultsCard').classList.remove('active');
            initQuiz();
        }

        // Inicializar quiz
        initQuiz();
        
        console.log('🧠 Quiz iniciado com', quizQuestions.length, 'perguntas');
        console.log('Perguntas:', quizQuestions);
    </script>
</body>
</html>